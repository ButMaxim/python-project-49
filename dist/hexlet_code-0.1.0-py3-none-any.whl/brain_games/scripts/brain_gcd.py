from brain_games.engine import start_game
from brain_games.games import gcd


def main():
	start_game(gcd)

