from brain_games.engine import start_game
from brain_games.games import calc


def main():
	start_game(calc)

